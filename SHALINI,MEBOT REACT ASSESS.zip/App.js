import React from "react";
import Footer from "./Footer";
import Header from "./Header";
import Cart from "./Cart";
import CheckOut from "./CheckOut";
import ProductDetails from "./ProductDetails";

function App(){
  return(
    <div>
      
     
      {
        
        <><Footer />
        <Header />
        <Cart />
        <CheckOut />
        <ProductDetails /></>
    }
    </div>
  );
}

export default App;