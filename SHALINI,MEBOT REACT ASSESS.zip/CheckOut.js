import React, { useState } from "react";
import "./CheckOut.css";
const CheckOut = () => {
  var [info, setIndo] = useState("");

  return (
    <div>
      <div className="name">
        <h1>Help and Customer service</h1>

        <ul>
          <li> Placing Orders</li>
          <li> Ordering with pinkyshop- FAQ</li>
          <li> Searching and Browsing for Items</li>
          <li> Proceed to Checkout</li>
          
          <li> Install or Uninstall pinkyshop Assistant</li>
          <li> Change Your Language and Marketplace in pinkyshop Assistant</li>
          <li> Coupons - FAQ</li>
          <li>  Defective- FAQ</li>
        </ul>
      </div>
      <div className="divide">
        <h3 className="more">Find more solutions</h3>
        <input type="text" className="text" value={info} />
        <h1 className="proceed">Proceed to CheckOut</h1>
        <p className="para">
          1.Select Proceed to Checkout
          <br />
          2.  sign in to your account or create a new account 
          
          <br />
          3. Enter a shipping address
          <br />
          4. Choose a shipping method
          <br />
          5. Enter your payment information
          <br />
          6. Review your order details
          <br />
          7. Select Place your order
        </p>
      </div>
    </div>
  );
};

export default CheckOut;