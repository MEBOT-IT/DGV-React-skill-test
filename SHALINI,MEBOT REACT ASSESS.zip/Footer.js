import React from "react";
import "./Footer.css";
const Footer = () => {
  return (
    <div className="full2">
      <ul className="a">
        <p className="para">Get to Know Us</p>
        <li>About Us</li>
        <li>Careers</li>
        <li>Press</li>
        <li>pinkyshop</li>
      </ul>
      <ul className="a2">
        <p className="para">Connect With Us</p>
        <li>Facebook</li>
        <li>Twitter</li>
        
      </ul>
      <ul className="a3">
        <p className="para">Make Money With Us</p>
        <li>Sell on pinkyshop</li>
   
        <li>Protext and build your Brand</li>
     
        <li>Advertise Your Products</li>
      </ul>
      <ul className="a4">
        <p className="para">Let Us Help You</p>
       
        <li>Your Accounts</li>
        <li>Returns Centre</li>
        <li> Purchase Protection</li>
        <li>pinkyshop App Download</li>
      </ul>
    </div>
  );
};

export default Footer;