import React, { useState } from "react";
import "./Header.css";
const Header = () => {
  var [items, setItems] = useState("");
  var handle = (item) => {
    console.log(item);
    setItems("");
  };
  return (
    <div className="full">
      <a href="#">
        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ6JEArnT0EBIWNj2_Oy17E7qO4h1EULUvCww&usqp=CAU"
          className="pinkyshop"
        />
      </a>

      <p className="hi">
        Hello <br />
        select your address
      </p>

      <input
        type="text"
        placeholder="Search pinkyshop.com"
        value={items}
        className="search"
        onChange={(e) => setItems(e.target.value)}
      />

      <button onClick={() => handle(items)} className="submit">
        search
      </button>
      <p className="a">
        Hi,sign in
        <br />
        Accounts 
      </p>
      <p className="a1">
        Returns
        <br />& Orders
      </p>
    </div>
  );
};

export default Header;